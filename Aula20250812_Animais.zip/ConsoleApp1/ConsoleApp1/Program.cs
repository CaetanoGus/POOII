﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("== SerVivo ==");
            SerVivo sv = new();
            sv.Nascer();
            sv.Crescer();
            sv.Morrer();


            Console.WriteLine("== Animal ==");
            Animal an = new();
            an.Nascer();
            an.Crescer();

            an.Nascer();
        }
    }
}

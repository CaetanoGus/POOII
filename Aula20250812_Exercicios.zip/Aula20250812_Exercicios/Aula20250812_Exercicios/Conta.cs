﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20250812_Exercicios
{
    internal class Conta(double limite, int numero, double saldo)
    {
        public double Limite { get; set; } = limite;

        public int Numero { get; set; } = numero;
        public double Saldo { get; set; } = saldo;

        public Cliente Correntista { get; set; }


        
        /* public void Depositar(double valor)
        {
            // Saldo = Saldo + valor;
            Saldo += valor;
        } */

        public void Depositar(double valor) => Saldo += valor;

        public bool Sacar(double valor)
        {
            if (Saldo > valor)
            { 
                Saldo -= valor;
                return true;
            }
            return false;
        }


        /* private bool VerificarTransacao(double valor)
        {
            if (Saldo > valor)
            {
                return true;
            }
            return false;
        } */

        private bool VerificarTransacao(double valor)
        {
            return Saldo > valor;
        }


    }
}

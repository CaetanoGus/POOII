﻿namespace VamosCodarOO_20250815
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== LOJA DE ROUPAS ONLINE ===");
        }
    }
}

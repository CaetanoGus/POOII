﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20250812_Exercicios
{
    internal class Cliente(string nome, string cpf, string endereco)
    {
        public string Nome { get; set; } = nome ?? throw new ArgumentNullException(nameof(nome));

        public string Cpf { get; set; } = cpf ?? throw new ArgumentNullException(nameof(cpf));

        public string Endereco { get; set; } = endereco ?? throw new ArgumentNullException( nameof(endereco));
    }
}

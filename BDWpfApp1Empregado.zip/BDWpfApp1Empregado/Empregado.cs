﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDWpfApp1Empregado
{
    internal class Empregado
    {
        public int Matricula {  get; set; } = 0;
        public string? CPF { get; set; }
        public string? Nome { get; set; }
        public string? Endereco { get; set; }

        public Empregado() { }
        
        public Empregado(string cPF, string nome, string endereco)
        {
            CPF = cPF;
            Nome = nome;
            Endereco = endereco;
        }

        public override string ToString()
        {
            //return base.ToString();
            return $"Empregado -> Matricula: {Matricula} | CPF: {CPF}" +
                                $"Nome: {Nome} | Endereço: {Endereco}";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Animal : SerVivo
    {
        public void Mover() => Console.WriteLine("Animal: Mover()");
        public void Respirar() => Console.WriteLine("Animal: Respirar()");

        // public void Nascer() => Console.WriteLine("SerVivo: Nascer()");
    }
}

namespace Guess_The_Word_Windows_Forms_MOO_ICT
{

    // Made by MOO ICT
    // For educational purpose only
    public partial class Form1 : Form
    {

        List<string> words = new List<string>();
        string newText;
        int i = 0;
        int guessed = 0;

        // Altera��o 1 � Sistema de Pontua��o
        int score = 0; // vari�vel global para guardar pontos

        // Altera��o 2 � Dicas
        int hints = 3; // limite de dicas

        // Altera��o 4 � Timer (Cron�metro)
        int timeLeft = 30;
        System.Windows.Forms.Timer gameTimer = new System.Windows.Forms.Timer();


        // Altera��o 2 � Dicas
        private void btnHint_Click(object sender, EventArgs e)
        {
            if (hints > 0)
            {
                string word = words[i];
                MessageBox.Show("Hint: a primeira letra � " + word[0]);
                hints--;
            }
            else
            {
                MessageBox.Show("Voc� n�o tem mais dicas!");
            }
        }

        // Altera��o 3 � Categorias de Palavras
        private void Setup(string categoria)
        {
            words = File.ReadLines("words.txt")
                        .Where(line => line.StartsWith(categoria + ":"))
                        .Select(line => line.Replace(categoria + ":", "").Trim())
                        .ToList();

            i = 0;
            newText = Scramble(words[i]);
            lblWord.Text = newText;
            lblInfo.Text = "Words: " + (i + 1) + " of " + words.Count;

            // Altera��o 4 � Timer (Cron�metro)
            StartTimer(); // inicia o cron�metro
        }

        private void cmbCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            string categoria = cmbCategoria.SelectedItem.ToString();
            Setup(categoria);
        }


        // Altera��o 4 � Timer (Cron�metro)
        private void StartTimer()
        {
            timeLeft = 30;
            lblTimer.Text = "Tempo: " + timeLeft;
            gameTimer.Stop();   // garante que n�o tem 2 timers rodando
            gameTimer.Start();
        }

        private void GameTimerEvent(object sender, EventArgs e)
        {
            if (timeLeft > 0)
            {
                timeLeft--;
                lblTimer.Text = "Tempo: " + timeLeft;
            }
            else
            {
                gameTimer.Stop();
                MessageBox.Show("Tempo acabou! A palavra era: " + words[i]);
                i++;
                if (i < words.Count)
                {
                    newText = Scramble(words[i]);
                    lblWord.Text = newText;
                    StartTimer();
                }
                else
                {
                    lblWord.Text = "Fim de jogo!";
                }
            }
        }

        //


        public Form1()
        {
            InitializeComponent();
            Setup();

            // Altera��o 4 � Timer (Cron�metro)
            // Configura��o do Timer (s� uma vez)
            gameTimer.Interval = 1000; // 1 segundo
            gameTimer.Tick += GameTimerEvent;
        }

        private void KeyIsPressed(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (words[i].ToLower() == textBox1.Text.ToLower())
                {
                    if (i < words.Count - 1)
                    {
                        MessageBox.Show("Correct!", "Moo Says: ");
                        textBox1.Text = "";
                        i += 1;
                        newText = Scramble(words[i]);
                        lblWord.Text = newText;
                        lblInfo.Text = "Words: " + (i + 1) + " of " + words.Count;
                        guessed = 0;
                        lblGussed.Text = "Guessed: " + guessed + " times.";


                        // Altera��o 1 � Sistema de Pontua��o
                        MessageBox.Show("Correct!", "Moo Says: ");
                        score += 10; // +10 pontos por acerto
                        lblScore.Text = "Score: " + score;
                    }
                    else
                    {
                        lblWord.Text = "You Win, Well done";
                        return;
                    }    
                }
                else
                {
                    guessed += 1;
                    lblGussed.Text = "Guessed: " + guessed + " times.";


                    // Altera��o 1 � Sistema de Pontua��o
                    score -= 2; // -2 pontos por erro
                    lblGussed.Text = "Guessed: " + guessed + " times.";
                    lblScore.Text = "Score: " + score;

                }
                e.Handled = true;
            }
        }

        private void Setup()
        {
            words = File.ReadLines("words.txt").ToList();
            newText = Scramble(words[i]);
            lblWord.Text = newText;
            lblInfo.Text = "Words: " + (i + 1) + " of " + words.Count;
        }

        private string Scramble(string text)
        {
            return new string(text.ToCharArray().OrderBy(x => Guid.NewGuid()).ToArray());
        }
    }
}
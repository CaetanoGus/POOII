﻿using Microsoft.Data.SqlClient;

namespace ConsoleApp1BD
{
    internal class Program
    {
        static void Main(String[] args)
        {
            SqlConnection conexao;

            conexao = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MyUniversidadeBD;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
            conexao.Open();
            Console.WriteLine("Conexão OK");


            Console.WriteLine("== Salvando dados no BD ==");

            var insertCmd = conexao.CreateCommand();
            insertCmd.CommandText = "INSERT INT Cursos (Nome, Periodo, Categoria) VALUES (@nome, @per, @cat)";

            var paramNome = new SqlParameter("nome", "POO");
            insertCmd.Parameters.Add(paramNome);

            var paramPeriodo = new SqlParameter("per", "10");
            insertCmd.Parameters.Add(paramPeriodo);

            var paramCategoria = new SqlParameter("cat", "Maneiro");
            insertCmd.Parameters.Add(paramCategoria);

            insertCmd.ExecuteNonQuery();

            conexao.Close();
        }
    }
}
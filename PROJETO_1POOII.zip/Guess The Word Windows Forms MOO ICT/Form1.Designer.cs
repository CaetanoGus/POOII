﻿namespace Guess_The_Word_Windows_Forms_MOO_ICT
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblWord = new Label();
            textBox1 = new TextBox();
            lblInfo = new Label();
            lblGussed = new Label();
            lblScore = new Label();
            btnHint = new Button();
            label2 = new Label();
            cmbCategoria = new ComboBox();
            lblTimer = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 26.25F);
            label1.Location = new Point(240, 19);
            label1.Name = "label1";
            label1.Size = new Size(274, 47);
            label1.TabIndex = 0;
            label1.Text = "Guess The Word";
            // 
            // lblWord
            // 
            lblWord.Font = new Font("Segoe UI", 21.75F);
            lblWord.ForeColor = Color.White;
            lblWord.Location = new Point(240, 118);
            lblWord.Name = "lblWord";
            lblWord.Size = new Size(274, 52);
            lblWord.TabIndex = 1;
            lblWord.Text = "label2";
            lblWord.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 21.75F);
            textBox1.Location = new Point(259, 204);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(255, 46);
            textBox1.TabIndex = 2;
            textBox1.TextAlign = HorizontalAlignment.Center;
            textBox1.KeyPress += KeyIsPressed;
            // 
            // lblInfo
            // 
            lblInfo.Font = new Font("Segoe UI", 18F);
            lblInfo.ForeColor = Color.FromArgb(192, 255, 255);
            lblInfo.Location = new Point(240, 280);
            lblInfo.Name = "lblInfo";
            lblInfo.Size = new Size(274, 52);
            lblInfo.TabIndex = 1;
            lblInfo.Text = "Words: 0 of 0";
            lblInfo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblGussed
            // 
            lblGussed.Font = new Font("Segoe UI", 18F);
            lblGussed.ForeColor = Color.FromArgb(255, 255, 192);
            lblGussed.Location = new Point(520, 203);
            lblGussed.Name = "lblGussed";
            lblGussed.Size = new Size(274, 47);
            lblGussed.TabIndex = 1;
            lblGussed.Text = "Guessed: 0 times";
            lblGussed.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblScore
            // 
            lblScore.Font = new Font("Segoe UI", 18F);
            lblScore.ForeColor = Color.LightGreen;
            lblScore.Location = new Point(240, 340);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(274, 52);
            lblScore.TabIndex = 0;
            lblScore.Text = "Score: 0";
            lblScore.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnHint
            // 
            btnHint.Font = new Font("Segoe UI", 14F);
            btnHint.Location = new Point(600, 280);
            btnHint.Name = "btnHint";
            btnHint.Size = new Size(100, 40);
            btnHint.TabIndex = 1;
            btnHint.Text = "Hint";
            btnHint.Click += btnHint_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(572, 323);
            label2.Name = "label2";
            label2.Size = new Size(159, 45);
            label2.TabIndex = 3;
            label2.Text = " Com grandes poderes vem \r\n grandes responsabilidades! \r\nVocê tem uma dica por jogo.";
            // 
            // cmbCategoria
            // 
            cmbCategoria.Items.AddRange(new object[] { "Animais", "Frutas", "Objetos" });
            cmbCategoria.Location = new Point(50, 50);
            cmbCategoria.Name = "cmbCategoria";
            cmbCategoria.Size = new Size(121, 23);
            cmbCategoria.TabIndex = 4;
            cmbCategoria.SelectedIndexChanged += cmbCategoria_SelectedIndexChanged;
            // 
            // lblTimer
            // 
            lblTimer.Font = new Font("Segoe UI", 18F);
            lblTimer.ForeColor = Color.Orange;
            lblTimer.Location = new Point(600, 50);
            lblTimer.Name = "lblTimer";
            lblTimer.Size = new Size(200, 40);
            lblTimer.TabIndex = 5;
            lblTimer.Text = "Tempo: 30";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(49, 84);
            label3.Name = "label3";
            label3.Size = new Size(126, 30);
            label3.TabIndex = 6;
            label3.Text = "Escolha uma categoria\r\n    para iniciar o jogo!";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DimGray;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(lblScore);
            Controls.Add(btnHint);
            Controls.Add(textBox1);
            Controls.Add(lblGussed);
            Controls.Add(lblInfo);
            Controls.Add(lblWord);
            Controls.Add(label1);
            Controls.Add(cmbCategoria);
            Controls.Add(lblTimer);
            ForeColor = Color.FromArgb(192, 192, 255);
            Name = "Form1";
            Text = "Guess The Word Game MOO ICT";
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private Label label1;
        private Label lblWord;
        private TextBox textBox1;
        private Label lblInfo;
        private Label lblGussed;

        // Alteração 1 – Sistema de Pontuação
        private Label lblScore;

        // Alteração 2 – Dicas
        private Button btnHint;
        private Label label2;

        // Alteração 3 – Categorias de Palavras
        private ComboBox cmbCategoria;

        // Alteração 4 – Timer (Cronômetro)
        private Label lblTimer;
        private Label label3;
    }
}
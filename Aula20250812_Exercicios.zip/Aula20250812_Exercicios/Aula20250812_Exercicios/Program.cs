﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula20250812_Exercicios
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Conta cc01 = new Conta(100, 1, 100);

            Cliente cl01 = new Cliente("Vinicius", "123", "Mora na UVV");

            cc01.Correntista = cl01;


            Console.WriteLine($"Saldo: {cc01.Saldo}");
            cc01.Depositar(200);
            Console.WriteLine($"Saldo: {cc01.Saldo}");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VamosCodarOO_20250815
{
    internal class Produto
    {
        // ========== Atributos ==========
        public string nome { get; set; }
        public double preco { get; set; }
        public int estoque { get; set; }


        // ========== Construtor ==========
        public Produto(string nome, double preco, int estoque)
        {
            this.nome = nome;
            this.preco = preco;
            this.estoque = estoque;
        }

        // ========== MÉTODOS ==========
        public void ValorTotalEstoque()
        {
            double valorTotal = preco * estoque;
            Console.WriteLine($"Valor total em estoque do produto {nome}: R$ {valorTotal:F2}");
        }
    }
}
